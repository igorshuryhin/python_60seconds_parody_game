import pygame

pygame.init()

group = pygame.sprite.Group()

print(len(group))